1. Language : TODO

2. Preconditions
   2.1. Install OpenSSL
        - Type 'openssl version' in CMD
        - If version is not printed, Visit https://slproweb.com/products/Win32OpenSSL.html to download and install (Light version is enough)
        - Add openssl install path to PATH environment variable
        - Close and open CMD again. Then type 'openssl version'
   2.2. TODO for anything for your submission

3. Scenario
   3.1. Carol generates RSA keypair and self-signed X.509 cert
        - ..\Carol> openssl genrsa -out CarolPriv.pem 2048
        - ..\Carol> openssl req -new -key CarolPriv.pem -out CarolCsr.pem -subj /CN=TODO/
        - ..\Carol> openssl x509 -req -days 365 -in CarolCsr.pem -signkey CarolPriv.pem -out CarolCert.pem
   3.2. Carol distributes her X.509
        - ..\Carol> copy CarolCert.pem ..\Bob\
   3.3. Alice generates RSA keypair and CSR
        - ..\Alice> openssl genrsa -out AlicePriv.pem 2048
        - ..\Alice> openssl req -new -key AlicePriv.pem -out AliceCsr.pem -subj /CN=Alice/
   3.4. Alice requests Carol to make signed X.509 
        - ..\Alice> copy AliceCsr.pem ..\Carol\
   3.5. Carol handles Alice's signing request
        - ..\Carol> openssl x509 -req -days 365 -CA CarolCert.pem -CAkey CarolPriv.pem -in AliceCsr.pem -out AliceCert.pem –CAcreateserial
   3.6. Carol gives Carol signed X.509 to Alice
        - ..Carol> copy AliceCert.pem ..\Alice\ 
   3.7. Alice Gives a message with its signature and signed X.509 to Bob
        - TODO
   3.8. Bob reads the message
        - TODO
   3.9. Bob verifies the message with its signature
        - TODO
   3.10. Bob verifies the Alice X.509 with Carol's
        - ..\Bob> openssl verify -CAfile CarolCert.pem AliceCert.pem


* Example
1. Language : Java

2. Preconditions
   2.1. Install OpenSSL
        - Type 'openssl version' in CMD
        - If version is not printed, Visit https://slproweb.com/products/Win32OpenSSL.html to download and install (Light version is enough)
        - Add openssl install path to PATH environment variable
        - Close and open CMD again. Then type 'openssl version'
   2.2. Install OpenJDK
        - Type 'java -version' in CMD
        - If version is not printed, Install OpenJDK and setup PATH environment
          ㆍOpenJDK download & install guide : https://openjdk.java.net/install/index.html
        - Close and open CMD again. Then type 'java -version'
   2.3. Build codes
        - ..\Alice> javac SignVeri.java
        - ..\Bob> javac SignVeri.java

3. Scenario
   3.1. Carol generates RSA keypair and self-signed X.509 cert
        - ..\Carol> openssl genrsa -out CarolPriv.pem 2048
        - ..\Carol> openssl req -new -key CarolPriv.pem -out CarolCsr.pem -subj /CN=YOUR_NAME/
        - ..\Carol> openssl x509 -req -days 365 -in CarolCsr.pem -signkey CarolPriv.pem -out CarolCert.pem
   3.2. Carol distributes her X.509
        - ..\Carol> copy CarolCert.pem ..\Bob\
   3.3. Alice generates RSA keypair and CSR
        - ..\Alice> openssl genrsa -out AlicePriv.pem 2048
        - ..\Alice> openssl req -new -key AlicePriv.pem -out AliceCsr.pem -subj /CN=Alice/
   3.4. Alice requests Carol to make signed X.509 
        - ..\Alice> copy AliceCsr.pem ..\Carol\
   3.5. Carol handles Alice’s signing request
        - ..\Carol> openssl x509 -req -days 365 -CA CarolCert.pem -CAkey CarolPriv.pem -in AliceCsr.pem -out AliceCert.pem –CAcreateserial
   3.6. Carol gives Carol signed X.509 to Alice
        - ..Carol> copy AliceCert.pem ..\Alice\ 
   3.7. Alice Gives a message with its signature and signed X.509 to Bob
        - ..\Alice> openssl pkcs8 -topk8 -inform PEM -outform PEM -nocrypt -in AlicePriv.pem -out AlicePriv.p8
        - ..\Alice> java SignVeri sign AlicePriv.p8 msg.txt
        - ..\Alice> copy msg.txt ..\Bob\
        - ..\Alice> copy msg.txt.sign ..\Bob\
        - ..\Alice> copy AliceCert.pem ..\Bob\       
   3.8. Bob reads the message
        - ..\Bob> type msg.txt
   3.9. Bob verifies the message with its signature
        - ..\Bob> java SignVeri verify AliceCert.pem msg.txt msg.txt.sign
   3.10. Bob verifies the Alice X.509 with Carol's
        - ..\Bob> openssl verify -CAfile CarolCert.pem AliceCert.pem
 